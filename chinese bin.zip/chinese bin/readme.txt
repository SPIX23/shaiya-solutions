replaced ps_login with nubness'

use the usp_Try_GameLogin_Taiwan
without that md5 hash shit or your 
account login probably won't work

the ps_login that came with these
files requires that md5 fuckery

ps_login modifications
sql injection solution - nubness
tls handshake soltuion - anton
decrease failed logins - bowie
client version -1 fail - bowie

connection overflow workaround
00411ABD - nop jnl (not applied)

mall.dll = ItemMallFix.dll
mall.sql is for mall.dll sql account
config.dll = 123123.dll

the config.ini that came with these files
will be useless because they didn't share
the dll that has the functions. i added
a 123123 dll with max enchant, and respawn
protection. the auto npc, and auto monster
functions are bugged. they spawn on time,
but do no get removed on time.

edit the mall.dll in hex to match the
username and password you chose and
keep them both 16 characters in length

avoid using sql operators in the username

removed unnecessary gg dlls
removed Test.exe
removed python27.dll (loaded by Test.exe)
added missing luas 133-172
removed the war files (useless shit?)
added war maps and obelisks to ini files
added svmaps 93-99 so the maps will load

server and pass are Shaiya Shaiya123

i didn't fuck with anything else - bowie


