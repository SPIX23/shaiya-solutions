use ps_gamedefs update items set reqluc = 0 where reqluc <> 0
use ps_gamedefs update items set server = 0 where server <> 0
use ps_gamedefs update items set reqwis = 0 where reqwis <> 0