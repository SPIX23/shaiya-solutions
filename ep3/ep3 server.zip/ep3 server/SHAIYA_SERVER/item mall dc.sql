exec sp_serveroption @server='game', @optname='rpc', @optvalue='true';
exec sp_serveroption @server='game', @optname='rpc out', @optvalue='true';